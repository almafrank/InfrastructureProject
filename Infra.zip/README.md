# InfrastructureProject
Infrastructure project that handles automatisation with Opentofu and Ansible.
